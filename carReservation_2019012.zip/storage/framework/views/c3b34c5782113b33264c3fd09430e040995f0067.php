<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header">Admin Login</div>
      <div class="card-body">
        <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo e(csrf_field()); ?>

          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
					<input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
					<?php if($errors->has('email')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</span>
					<?php endif; ?>
          </div>
          <div class="form-group">
            <label for="exampleInputPassword1">Password</label>
		
					
					<input id="password" type="password" class="form-control" name="password" required>

					<?php if($errors->has('password')): ?>
						<span class="help-block">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</span>
					<?php endif; ?>			
					
					
          </div>
          <div class="form-group">
            <div class="form-check">
					<label>
						<input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
					</label>
          </div>
								<button type="submit" class="btn btn-primary btn-block">
                                    Login
                                </button>
        </form>
        <div class="text-center">
          <a class="d-block small" href="<?php echo e(route('password.request')); ?>">Forgot Password?</a>
        </div>
      </div>
    
	
	</div>
  </div>
    
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>