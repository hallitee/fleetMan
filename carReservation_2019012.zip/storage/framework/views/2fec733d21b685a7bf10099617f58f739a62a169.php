<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->
   

      <!-- Area Chart Example-->

      <div class="row">
        <div class="col-md-12">
			
			<div class="page-header">
			<?php if(session('status')): ?>
				<div class="alert alert-<?php echo e(session('alert')); ?> h4 text-center">
					<?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>			
            </div> 
			
				  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header"> New Vehicle Reservation </div>
      <div class="card-body">
       <?php echo e(Form::open(['action' => array('RequestController@update', $req->id),'id'=>'reqstore', 'name'=>'reservation','method'=>'PUT'])); ?>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">First name * </label>
                <?php echo e(Form::text('firstName',(explode(' ',$req->reqName)[0]),array('class' => 'input-md form-control', 'readonly','placeholder'=>'Enter first name'))); ?> 
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Last name *</label>
               	<?php echo e(Form::text('lastName',(explode(' ',$req->reqName)[1]),array('class' => 'input-md form-control', 'readonly','placeholder'=>'Enter last name'))); ?> 
              </div>
            </div>
          </div>
	  
          <div class="form-group">
            <label for="exampleInputEmail1">Email address *</label>
            <input class="form-control" id="exampleInputEmail1" type="email" aria-describedby="emailHelp" name="email" value="<?php echo e($req->reqEmail); ?>" placeholder="Enter email" readonly> 
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">HOD Email *</label>
            <input class="form-control" type="text" aria-describedby="emailHelp" name="hodemailfbf" value="<?php echo e($req->hodName); ?>" placeholder="Enter email" readonly>
          </div>		  
		  		<input type="hidden" name="hodid" id="hodid">
		   <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Company *</label>
				<?php echo e(Form::text('company',$req->reqComp,array('class' => 'input-md form-control','readonly'))); ?> 
           
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Department *</label>
				<?php echo e(Form::text('dept',$req->reqDept,array('class' => 'input-md form-control','readonly'))); ?> 
              </div>
            </div>
          </div>
		  

		    <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Location *</label>
				<?php echo e(Form::text('location',$req->location,array('class' => 'input-md form-control','readonly'))); ?>

			           
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Destination *</label>
				<?php echo e(Form::text('dest',$req->reqDest,array('class' => 'input-md form-control','readonly'))); ?> 
              </div>
            </div>
          </div>
		  
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Date *</label>
				<span class="errDate text-danger"></span>
                 <?php echo e(Form::date('tripDate',$req->reqDate,array('class' => 'input-md form-control','placeholder'=>'Enter Date', 'readonly'))); ?> 
              </div>
              <div class="col-md-3">
                <label for="exampleConfirmPassword">Time *</label>
				<span class="errTime text-danger"></span>
                <?php echo e(Form::time('tripTime',$req->reqTime,array('class' => 'input-md form-control ','placeholder'=>'Enter Time','readonly'))); ?> 
              </div>
              <div class="col-md-3">
                <label for="exampleConfirmPassword">Duration(min) *</label>
				<span class="errTime text-danger"></span>
                <?php echo e(Form::text('tripDur',$req->reqDur,array('class' => 'input-md form-control ','placeholder'=>'Enter Duration','id'=>'tripDur','required','readonly'))); ?> 
              </div>			  
            </div>
          </div>
		  
		  

		  
			<div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Passenger</label>
				<?php echo e(Form::text('passenger',$req->reqPass,array('class' => 'form-control','placeholder'=>'Enter passengers','readonly'))); ?> 
           
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Load </label>
				<?php echo e(Form::text('load', ($req->passLoad) ? 'YES':'NO',array('class' => 'input-md form-control','readonly'))); ?> 
              </div>
            </div>
          </div>
	
	


			<div class="form-group">
            <label for="exampleInputEmail1">Purpose</label>
            
			<?php echo e(Form::textarea('notes',$req->purpose,array('size'=>'70x3', 'class' => 'form-control','maxlength'=>100,'required','readonly') )); ?>	
          </div>
		  	<div class="form-group">
            <label for="exampleInputEmail1">HOD Remarks</label>            
			<?php echo e(Form::textarea('hodnotes','',array('size'=>'70x2', 'class' => 'form-control','maxlength'=>300,'id'=>'hodnotes','required') )); ?>	
			</div>
		  
		  
		  			<div class="form-group">
            <div class="form-row">
			<div class="col-md-6">
					  <?php echo e(Form::submit('APPROVE',array('class' => 'btn btn-success btn-block subBtn','name'=>'subBtn'))); ?> 
         </div>
		 	<div class="col-md-6">
					<?php echo e(Form::submit('DISMISS',array('class' => 'btn btn-danger btn-block  subBtn','name'=>'subBtn'))); ?> 
			</div>
          </div>

		<?php echo e(Form::close()); ?>

		
      </div>
    </div>
  </div>
 				
		
        </div>

      </div>

  
	</div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>