<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->
   

      <!-- Area Chart Example-->

      <div class="row">
        <div class="col-md-12">
			
			<div class="page-header">
			<?php if(session('status')): ?>
				<div class="alert alert-<?php echo e(session('alert')); ?> h4 text-center">
					<?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>			
            </div> 
			
				  <div class="container">
	<div class="card mx-auto">
		<?php if($req): ?>
      <div class="card-header text-center"><div class="h4"><?php if($req->reqStatus<10): ?> STATUS TRACKING <?php else: ?> STATUS TRACKING <?php endif; ?> </div></div>
      <div class="card-body">
	  					
				  <ul class="list-unstyled multi-steps">
					<?php if($req->reqStatus==NULL): ?> 
					<li class="is-active">Awaiting Approval</li>
					<?php elseif($req->reqStatus==1): ?>
					<li class="is-active">System cancelled</li>
					<?php endif; ?>
					<?php if(($req->reqStatus==8)): ?>
					<li class="is-active">Dismissed By HOD</li>
					<?php elseif($req->reqStatus==5): ?>
					<li class="is-active">Cancelled By User</li>
					<?php else: ?>
					<li <?php if($req->reqStatus==10): ?> class="is-active" <?php endif; ?>>Approved By HOD</li>	
					<?php endif; ?>				
					<?php if($req->reqStatus==15): ?>
					<li class="is-active">Decline BY GA</li>
					<?php else: ?>
					<li  <?php if($req->reqStatus==20): ?> class="is-active" <?php endif; ?>>Car Allocated</li>
					<?php endif; ?>
					<li <?php if($req->reqStatus==25): ?> class="is-active" <?php endif; ?>>Trip Start</li>
					<?php if($req->reqStatus==28): ?>
					<li>Trip Overtime</li>
					<li   class="is-active">Completed</li>
					<?php else: ?>
					<li>Trip End</li>
					<li   class="is-active">Completed</li>
					<?php endif; ?>
				  </ul>		
			
		<div class="table-responsive">
            <table class="table table-bordered" id="datatable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th colspan="4" class="text-center">Request Details</th>
 
                </tr>
              </thead>        
			  <tbody>
                <tr>
                  <th>First Name:</th>
                  <td><?php echo e((explode(' ',$req->reqName)[0])); ?></td>
                  <th>Last Name:</th>
                  <td><?php echo e((explode(' ',$req->reqName)[1])); ?></td>             
                </tr>  
                <tr>
                  <th>Email:</th>
                  <td><?php echo e($req->reqEmail); ?></td>    
                  <th>Tracking Code:</th>
                  <td><?php echo e($req->reqCode); ?></td>                             
                </tr> 
                <tr>
                  <th>Company:</th>
                  <td><?php echo e($req->reqComp); ?></td>
                  <th>Department:</th>
                  <td><?php echo e($req->reqDept); ?></td>             
                </tr>				
                <tr>
                  <th>Location:</th>
                  <td><?php echo e($req->location); ?></td>
                  <th>Destination:</th>
                  <td><?php echo e($req->reqDest); ?></td>             
                </tr>
                <tr>
                  <th>Date:</th>
                  <td><?php echo e($req->reqDate); ?></td>
                  <th>Time:</th>
                  <td><?php echo e($req->reqTime.' HR'); ?></td>             
                </tr>
                <tr>
                  <th>Passenger:</th>
                  <td><?php echo e($req->reqPass); ?></td>
                  <th>Load:</th>
                  <td><?php echo e($req->passLoad); ?></td>             
                </tr>	
                <tr>
                  <th>HOD Email:</th>
                  <td colspan="3"><?php echo e($req->hodName); ?></td>                              
                </tr> 	
                <tr>
                  <th>Purpose:</th>
                  <td colspan="3"><?php echo e($req->purpose); ?></td>                              
                </tr> 	
<?php if($req->hodRemark): ?>
                <tr>
                  <th>HOD Remark:</th>
                  <td colspan="3"><?php echo e($req->hodRemark); ?></td>                              
                </tr> 			
<?php endif; ?>				
              </tbody>
            </table>
         
		 </div>
  <?php if(Auth::guest() && (($req->reqStatus==NULL)||($req->reqStatus==10)||($req->reqStatus==20)) ): ?>
		
			<hr>
			
			<?php echo Form::open(['action' => array('RequestController@tracking'),'method'=>'GET','id'=>'canTrip']); ?>

				<input type="hidden" id="tripDate">
			 <br>
			 <?php echo e(Form::textarea('canRem','',array('size'=>'50x3', 'class' => 'form-control','maxlength'=>500,'required','placeholder'=>'Enter cancel remark','id'=>'canRem','style'=>'display:none') )); ?>

			 <br>			 
			  <br>
			 
			  <div class="form-group row">
			<input type="hidden" value="<?php echo e($req->id); ?>" name="reqID">
		 	<div class="col-md-4 offset-md-4">
				<?php echo e(Form::button('Cancel Trip',array('class' => 'btn btn-danger btn-block','name'=>'subBtn', 'id'=>'cancelTrip'))); ?> 
			</div>

			  </div>
		<?php echo Form::close(); ?>

		<?php endif; ?>	

		 </div>
		 <?php else: ?>
			       <div class="card-header text-center"><div class="h4 text-danger">No record found </div></div>
      <div class="card-body">
		 <?php endif; ?>
		 </div>
 				
		
        </div>

      </div>

  
	</div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>