<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->   

      <!-- Area Chart Example-->
      <div class="row">
        <div class="col-md-12">			
			<div class="page-header">
			<?php if(session('status')): ?>
				<div class="alert alert-<?php echo e(session('alert')); ?> h4 text-center">
					<?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>			
            </div> 				
        </div>
      </div>  
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Reservation List</div>
        <div class="card-body">
			<?php echo $__env->make('listing', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
      </div>
  
  
  
	</div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>