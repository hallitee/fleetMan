  <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
				  <th>#</th>
                  <th>Code</th>
				  <?php if(Auth::user()->role>3): ?><th> DB_id</th><?php endif; ?>
                  <th>Requestor</th>
                  <th>Department</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Destination</th>
				  <th>Status</th>
				  <th>Action</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
				  <th>#</th>
                  <th>Code</th>
				  <?php if(Auth::user()->role>3): ?><th> DB_id</th><?php endif; ?>
                  <th>Requestor</th>
                  <th>Department</th>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Destination</th>
				  <th>Status</th>
				  <th>Action</th>
                </tr>
              </tfoot>
              <tbody>
			  <?php $__currentLoopData = $req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($r->reqCode); ?></td>
				  <?php if(Auth::user()->role>3): ?><td> <?php echo e($r->id); ?></td><?php endif; ?>
                  <td><?php echo e($r->reqName); ?></td>
                  <td><?php echo e($r->reqDept); ?></td>
                  <td><?php echo e($r->reqDate); ?></td>
				  <td><?php echo e($r->reqTime); ?></td>
                  <td><?php echo e($r->reqDest); ?></td>
				  <td>
				  <?php  
				  $request=$r->reqStatus;
				  if($r->reqStatus==NULL){
					  echo "<strong class='text-info'>AWAITING APPROVAL</strong>";
				  }
				  elseif($r->reqStatus==1){
					  echo "<strong class='text-info'>SYSTEM CANCELLED</strong>"; 
				  }
				elseif($r->reqStatus==5){
					 echo "<strong class='text-danger'>CANCELLED BY USER</strong>";
				  }				  
				  elseif($r->reqStatus==10){
					 echo "<strong class='text-primary'>APPROVED BY HOD</strong>";
				  }
				  elseif($r->reqStatus==8){
					 echo "<strong class='text-danger'>DISMISSED BY HOD</strong>";
				  }				  
				  elseif($r->reqStatus==15){
					 echo "<strong class='text-danger'>G.A DECLINED</strong>";
				  }	
				  elseif($r->reqStatus==20){
					 echo "<strong class='text-warning'>RESERVED</strong>";
				  }	
				  elseif($r->reqStatus==25){
					 echo "<strong class='text-success'>TRIP START</strong>";
				  }	
				  elseif($r->reqStatus==28){
					 echo "<strong class='text-danger'>TRIP OVERTIME</strong>";					
				  }	
				  elseif($r->reqStatus==30){
					echo "<strong class='text-success'>COMPLETED</strong>";
				  }						  
				   ?>
				  </td>
                  <td>
				
						<div class="text-center">
						  <a style="text-decoration:none;margin-bottom:2px" class="d-block small" href="<?php echo e(route('reserve.edit', $r->id)); ?>">
						  <button class="btn btn-primary btn-block">Review</button>
						  </a>
						  <?php if($r->reqStatus>=20): ?>				
 						  <a style="text-decoration:none;margin-bottom:2px" class="d-block small" href="<?php echo e(route('reserve.gate', [$r->id,$r->reqCode])); ?>">
						  <button class="btn btn-success btn-block">Gatepass</button>
						  </a>
						  <?php endif; ?>
							<?php if(Auth::user()->role>3): ?>
 						  <a style="text-decoration:none;margin-bottom:2px" class="d-block small" href="<?php echo e(route('reserve.push', [$r->id,$r->reqCode])); ?>">
						  <button class="btn btn-warning btn-block">Push Email</button>
						  </a>								
							<?php endif; ?>
						</div>  
				
				  
				  </td>				  
                </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        
		