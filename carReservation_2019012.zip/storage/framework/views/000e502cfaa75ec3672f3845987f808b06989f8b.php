<html>
<head>
<style>
.table1 {
	border-collapse: collapse;
	}
.table1 th{

	border: 1px solid black
	}
.table1 td{

	border: 1px solid black
	}
</style>
</head>
<body>
Dear <?php echo e(ucfirst(explode(".", explode("@",$email)[0])[0])); ?>,
<br>
<br>
The below car reservation request has been approved for your action, 
<br>
<br>
<br>
<table class="table1">
<tr><td colspan='4' style="text-align:center">Request Information</td>  </tr>
<tr><th>First Name:</th><td><?php echo e(explode(' ',$form->reqName)[0]); ?></td>
<th>Last Name:</th><td><?php echo e(explode(' ',$form->reqName)[1]); ?></td></tr>
<tr><th>Email Address:</th><td colspan="3"><?php echo e($form->reqEmail); ?></td></tr>
<tr><th>Company:</th><td><?php echo e($form->reqComp); ?></td>
<th>Department:</th><td><?php echo e($form->reqDept); ?></td></tr>
<tr><th>Location:</th><td><?php echo e($form->location); ?></td>
<th>Destination:</th><td><?php echo e($form->reqDest); ?></td></tr>
<tr><th>Date:</th><td><?php echo e($form->reqDate); ?></td>
<td><b>Time:</b> <?php echo e($form->reqTime.' HR'); ?></td>
<td><b>Duration: </b><?php echo e($form->reqDur.' '.' min'); ?></td>   </tr>
<tr>
<th>Passenger:</th><td><?php echo e($form->reqPass); ?></td>
<th>Load:</th>
<td>
<?php if($form->passLoad): ?>
	YES
<?php else: ?>
	NO
<?php endif; ?>
</td>
</tr>

<tr><th>Purpose:</th><td colspan='3' style="text-align:left"><?php echo e($form->purpose); ?></td>
</tr>
<tr>
<th>Approved by (HOD):</th><td><?php echo e($form->hod); ?></td><th> Approval Date:</th><td><?php echo e($form->hodAppr); ?></td></tr>
<th>HOD Remark:</th><td colspan="3"><?php echo e($form->hodRemark); ?></td></tr>
</table>
<br>
<br>
Please click the link below to login into the portal.
<br>
<a href="<?php echo e(route('login')); ?>"> Car Reservation Portal </a>
<br>
<br>
<br>
IT Department
</body>
</html>