   <?php $__env->startSection('js'); ?>
   <script>
   	function pad(t) {
   var st = "" + t;

   while (st.length < 2)
   st = "0" + st;

   return st;  
	}
   	document.getElementById("tripDate").valueAsDate = new Date();
	local = new Date();
	localTime = pad((local.getHours()+1)) + ":" + pad(local.getMinutes());
	document.getElementById("tripTime").value = localTime;	

   </script>
   
   <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
      <!-- Breadcrumbs-->
   

      <!-- Area Chart Example-->

      <div class="row">
        <div class="col-md-12">
			
			<div class="page-header">
			<?php if(session('status')): ?>
				<div class="alert alert-<?php echo e(session('alert')); ?> h4 text-center">
					<?php echo e(session('status')); ?>

				</div>
			<?php endif; ?>			
            </div> 
			
				  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header"> New Vehicle Reservation </div>
      <div class="card-body">
       <?php echo e(Form::open(['action' => array('RequestController@store'),'id'=>'reqstore', 'name'=>'reservation'])); ?>

          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">First name * </label>
                <?php echo e(Form::text('firstName',"",array('class' => 'input-md form-control', 'required','placeholder'=>'Enter first name'))); ?> 
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Last name *</label>
               	<?php echo e(Form::text('lastName',"",array('class' => 'input-md form-control', 'required','placeholder'=>'Enter last name'))); ?> 
              </div>
            </div>
          </div>
	  
          <div class="form-group">
            <label for="exampleInputEmail1">Email address *</label>
            <input class="form-control" id="exampleInputEmail1" type="email" aria-describedby="emailHelp" name="email" placeholder="Enter email" required> 
          </div>
		  
		  		<input type="hidden" name="hodid" id="hodid">
		   <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Company *</label>
				<?php echo e(Form::select('company',config('app.company'),"",array('class' => 'input-md form-control','id'=>'company','required'))); ?>            
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Department *</label>
				<?php echo e(Form::select('dept',config('app.department'),"",array('class' => 'input-md form-control','id'=>'dept','required'))); ?> 
              </div>
            </div>
          </div>
		  

		    <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Location *</label>
				<?php echo e(Form::select('location',config('app.location'),"",array('class' => 'input-md form-control','id'=>'location','required'))); ?>

			           
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Destination *</label>
				<?php echo e(Form::select('dest',[],'',array('class' => 'input-md form-control','id'=>'dest','required'))); ?> 
              </div>
			<div class="col-md-4 other" style='display:none'>
                <label for="exampleInputLastName">Others *</label>
				<?php echo e(Form::text('otherDest','',array('class' => 'input-md form-control'))); ?> 
              </div>
            </div>
          </div>
		  <?php if(Auth::check()): ?>
		 <?php if((Auth::user()->role)>=3): ?>
		    <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label class="col-md-6" for="exampleInputName"><strong>Emergency Booking</strong>
				<span><input type="checkbox" name="urgent"  id="urgent">  </span></label>
              </div>
            </div>
          </div>
		<?php endif; ?>
		<?php endif; ?>		  
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="exampleInputPassword1">Date (YYYY-MM-DD) *</label>
				<span class="errDate small text-danger"></span>
                 <?php echo e(Form::date('tripDate',date('m/d/Y'),array('class' => 'input-md form-control','placeholder'=>'Enter Date','id'=>'tripDate', 'required'))); ?> 
              </div>
              <div class="col-md-4">
                <label for="exampleConfirmPassword">Time (HH:MM) *</label>
				<span class="errTime small text-danger"></span>
                <?php echo e(Form::time('tripTime','',array('class' => 'input-md form-control ','placeholder'=>'Enter Time','id'=>'tripTime','required'))); ?> 
              </div>
              <div class="col-md-4">
                <label for="exampleConfirmPassword">Duration(min) *</label>
			
                <?php echo e(Form::number('tripDur','',array('class' => 'input-md form-control ','placeholder'=>'Enter Duration','min'=>'30', 'id'=>'tripDur','required'))); ?> 
              </div>			  
            </div>
          </div>
		  	  
			<div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">Passenger</label>
				<?php echo e(Form::select('passenger',config('app.passenger'),"",array('class' => 'form-control','placeholder'=>'Enter passengers'))); ?> 
           
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Load </label>
				<?php echo e(Form::select('load',[''=>'','1'=>'YES','0'=>'NO'],"",array('class' => 'input-md form-control'))); ?> 
              </div>
            </div>
          </div>
	
	          <div class="form-group">
				<label for="exampleInputEmail1">HOD Email *</label>
				<input class="form-control" id="hodemail" type="hodemail" aria-describedby="emailHelp" name="hodemail" placeholder="Enter email" readonly required>
			  </div>


			<div class="form-group">
            <label for="exampleInputEmail1">Purpose *</label>
            
			<?php echo e(Form::textarea('notes','',array('size'=>'70x3', 'class' => 'form-control','maxlength'=>300,'id'=>'notes','required') )); ?>	
          </div>
		  
		  <?php echo e(Form::submit('Make Reservation',array('class' => 'btn btn-primary btn-block  submt'))); ?> 
         
      
		<?php echo e(Form::close()); ?>

		
      </div>
    </div>
  </div>
 				
		
        </div>

      </div>

  
	</div>
   <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>